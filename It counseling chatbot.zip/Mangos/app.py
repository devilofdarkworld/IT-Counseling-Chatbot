from flask import Flask, render_template, request, jsonify
from nltk.chat.util import Chat, reflections

app = Flask(__name__)

# Define the conversation patterns
pairs = [
    [
        r"(.*)your name ?",
        ["My name is CounselBot, and I'm here to help you with IT training-related questions."]
    ],
    [
        r"how are you ?",
        ["I'm doing great! How can I assist you today?", "I'm good! What about you?"]
    ],
    [
        r"(.*) courses do you offer?",
        ["We offer various courses including Python, Data Science, Cybersecurity, Web Development, Machine Learning, and more."]
    ],
    [
        r"(.*) course duration ?",
        ["Our courses typically last between 3 to 6 months, depending on the complexity and depth."]
    ],
    [
        r"(.*) fees (.*)",
        ["The fees for our courses range from $500 to $1500. We also offer discounts and scholarships for eligible candidates."]
    ],
    [
        r"(.*) flexible timings ?",
        ["Yes, we offer flexible timings, including weekend and evening batches to accommodate working professionals."]
    ],
    [
        r"(.*) job assistance ?",
        ["Absolutely! We provide job assistance, including resume building, interview preparation, and placement support."]
    ],
    [
        r"(.*) certifications (.*) courses?",
        ["Yes, all our courses come with industry-recognized certifications upon completion."]
    ],
    [
        r"how to enroll (.*)?",
        ["You can enroll by visiting our website and filling out the registration form. If you need help, feel free to contact our support team."]
    ],
    [
        r"what are the prerequisites (.*) course?",
        ["Most of our courses require basic knowledge of computers and programming. Some advanced courses may have specific prerequisites."]
    ],
    [
        r"do you offer online (.*)?",
        ["Yes, we offer online courses that provide the same content and certification as our in-person classes."]
    ],
    [
        r"do you provide (.*) practical training?",
        ["Yes, we focus on hands-on practical training with real-world projects to ensure you gain industry-relevant skills."]
    ],
    [
        r"(.*) doubt clearing sessions?",
        ["We have regular doubt-clearing sessions and one-on-one mentoring to help you with any challenges."]
    ],
    [
        r"(.*) payment options?",
        ["You can pay the fees via credit/debit cards, net banking, or EMI options. We also offer installment plans."]
    ],
    [
        r"(.*) scholarship (.*)?",
        ["Yes, we offer scholarships for meritorious students. Please visit our website or contact support for more details."]
    ],
    [
        r"(.*) about the trainers?",
        ["Our trainers are industry experts with years of experience. They are here to provide both theoretical and practical knowledge."]
    ],
    [
        r"how can I contact support?",
        ["You can reach our support team via email, phone, or live chat on our website."]
    ],
    [
        r"quit",
        ["Goodbye! If you have more questions, feel free to ask later. Have a great day!"]
    ],
    [
        r"(.*)",
        ["I'm sorry, I don't understand that. Could you please rephrase?"]
    ],
]

# Create the chatbot
chatbot = Chat(pairs, reflections)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    user_message = request.json['message']
    response = chatbot.respond(user_message)
    return jsonify({'response': response})

if __name__ == "__main__":
    app.run(debug=True)
