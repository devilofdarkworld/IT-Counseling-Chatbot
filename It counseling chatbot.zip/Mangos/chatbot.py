import nltk
from nltk.chat.util import Chat, reflections

# Pairs is a list of patterns and responses
pairs = [
    [
        r"(.*)your name ?",
        ["My name is CounselBot.",]
    ],
    [
        r"how are you ?",
        ["I'm doing great, thank you!", "I'm good! How about you?",]
    ],
    [
        r"what courses do you offer ?",
        ["We offer Python, Data Science, Web Development, and Machine Learning.",]
    ],
    [
        r"how to enroll ?",
        ["You can enroll by visiting our website and filling out the registration form.",]
    ],
    [
        r"what is the fee structure ?",
        ["Our courses range from $500 to $1500. We also offer discounts and scholarships.",]
    ],
    [
        r"quit",
        ["Goodbye! Have a great day!",]
    ],
]

# Default reflections
reflections = {
    "i am": "you are",
    "i was": "you were",
    "i": "you",
    "i'd": "you would",
    "i've": "you have",
    "i'll": "you will",
    "my": "your",
    "you are": "I am",
    "you were": "I was",
    "you've": "I have",
    "you'll": "I will",
    "your": "my",
    "yours": "mine",
    "you": "me",
    "me": "you"
}

# Create Chat object
chatbot = Chat(pairs, reflections)

# Start conversation
print("Hello! I am CounselBot. How can I assist you today? (type 'quit' to exit)")

while True:
    user_input = input("You: ").lower()
    if user_input == "quit":
        print("CounselBot: Goodbye! Have a great day!")
        break
    response = chatbot.respond(user_input)
    print(f"CounselBot: {response}")
